<div class="bg-white border border-green-200 rounded shadow-sm p-4 text-center hover:shadow-md transition">
  <a href="{{ $link }}" class="text-decoration-none">
    <h5 class="text-success fw-bold">{{ $title }}</h5>
    <p class="text-muted small mt-1">Klik untuk info lebih lanjut</p>
  </a>
</div>
